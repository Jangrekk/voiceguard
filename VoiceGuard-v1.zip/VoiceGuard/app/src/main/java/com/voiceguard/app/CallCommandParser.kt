package com.voiceguard.app

/**
 * Interprète la réponse vocale pendant un appel qui sonne :
 *  - « oui », « décroche », « réponds »    → répondre ;
 *  - « refuse », « raccroche », « rejette » → refuser (raccrocher) ;
 *  - « non », « ne réponds pas »            → ne rien faire, l'appel continue de sonner.
 */
object CallCommandParser {

    enum class Command { ANSWER, REJECT, IGNORE, UNKNOWN }

    private val ANSWER_WORDS = setOf(
        "oui", "ouais", "ouai", "yes", "yeah", "ok", "okay", "accord", "daccord",
        "decroche", "decrocher", "decrochez", "reponds", "repondre", "repondez",
        "prends", "prend", "passe", "vas",
        "waaw", "waw" // oui en wolof
    )

    private val REJECT_WORDS = setOf(
        "refuse", "refuser", "refusez", "rejette", "rejeter", "raccroche", "raccrocher",
        "coupe", "couper"
    )

    private val NEGATION_WORDS = setOf(
        "non", "no", "nope", "nan", "pas", "jamais", "laisse", "laissez", "stop",
        "ignore", "ignorer", "tard", "negatif",
        "deedeet", "deet" // non en wolof
    )

    fun parse(alternatives: List<String>): Command {
        for (candidate in alternatives) {
            val command = parseOne(candidate)
            if (command != Command.UNKNOWN) return command
        }
        return Command.UNKNOWN
    }

    fun parseOne(raw: String): Command {
        val tokens = YesNoParser.normalize(raw).split(' ').filter { it.isNotEmpty() }
        val hasReject = tokens.any { it in REJECT_WORDS }
        val hasNegation = tokens.any { it in NEGATION_WORDS }
        val negatedForm = tokens.any { it == "pas" || it == "jamais" || it == "ne" }

        if (hasReject) {
            // « ne raccroche pas » est ambigu : on préfère redemander.
            return if (negatedForm) Command.UNKNOWN else Command.REJECT
        }
        if (hasNegation) return Command.IGNORE
        if (tokens.any { it in ANSWER_WORDS }) return Command.ANSWER
        return Command.UNKNOWN
    }
}
