package com.voiceguard.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationDeduperTest {

    @Test
    fun sameKeyAndContentIsDuplicateWithinWindow() {
        val t0 = 1_000_000_000L
        assertFalse(NotificationDeduper.isDuplicate("k1", "com.whatsapp", "Babacar", "Salut", t0))
        assertTrue(NotificationDeduper.isDuplicate("k1", "com.whatsapp", "Babacar", "Salut", t0 + 5_000))
    }

    @Test
    fun sameContentAfterWindowIsNewAgain() {
        val t0 = 2_000_000_000L
        assertFalse(NotificationDeduper.isDuplicate("k2", "com.whatsapp", "Awa", "Ok", t0))
        assertFalse(NotificationDeduper.isDuplicate("k2", "com.whatsapp", "Awa", "Ok", t0 + 200_000))
    }

    @Test
    fun differentTextIsNotDuplicate() {
        val t0 = 3_000_000_000L
        assertFalse(NotificationDeduper.isDuplicate("k3", "com.whatsapp", "Moussa", "Un", t0))
        assertFalse(NotificationDeduper.isDuplicate("k3", "com.whatsapp", "Moussa", "Deux", t0 + 1_000))
    }
}
