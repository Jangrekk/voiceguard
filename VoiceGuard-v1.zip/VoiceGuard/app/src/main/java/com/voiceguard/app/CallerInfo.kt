package com.voiceguard.app

/** Appelant d'un appel entrant : le nom vient des contacts, le numéro du journal d'appels. */
data class CallerInfo(val name: String?, val number: String?) {

    /** Phrase d'annonce (sans la question). */
    fun spoken(): String = when {
        !name.isNullOrBlank() -> "Appel entrant de $name."
        !number.isNullOrBlank() -> "Appel entrant du numéro ${speakableNumber(number)}."
        else -> "Appel entrant. Numéro masqué."
    }
}

/**
 * Prépare un numéro pour la synthèse vocale : sans indicatif sénégalais (221),
 * groupé par deux chiffres pour qu'il soit lu comme un numéro et non comme un énorme nombre.
 */
fun speakableNumber(number: String): String {
    var digits = number.filter { it.isDigit() }
    if (digits.startsWith("221") && digits.length == 12) digits = digits.drop(3)
    return digits.chunked(2).joinToString(" ")
}
