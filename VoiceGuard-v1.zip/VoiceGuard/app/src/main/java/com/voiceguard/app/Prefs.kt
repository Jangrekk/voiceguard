package com.voiceguard.app

import android.content.Context

/** Réglages locaux : assistant, appels entrants, réponse vocale et applications en sourdine. */
object Prefs {
    private const val NAME = "voiceguard_prefs"
    private const val KEY_ENABLED = "assistant_enabled"
    private const val KEY_CALLS = "calls_enabled"
    private const val KEY_CALL_PERM_ASKED = "call_permissions_asked"
    private const val KEY_REPLIES = "replies_enabled"
    private const val KEY_MUTED = "muted_apps"
    private const val KEY_SEEN = "seen_apps"
    private const val MAX_SEEN = 80

    private fun prefs(context: Context) =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun isCallsEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_CALLS, false)

    fun setCallsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_CALLS, enabled).apply()
    }

    /** Vrai une fois que la fenêtre de permissions d'appels a été montrée au moins une fois. */
    fun wasCallPermissionAsked(context: Context): Boolean =
        prefs(context).getBoolean(KEY_CALL_PERM_ASKED, false)

    fun setCallPermissionAsked(context: Context, asked: Boolean) {
        prefs(context).edit().putBoolean(KEY_CALL_PERM_ASKED, asked).apply()
    }

    /** Réponse vocale aux messages : activée par défaut (elle ne demande aucune permission). */
    fun isRepliesEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_REPLIES, true)

    fun setRepliesEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_REPLIES, enabled).apply()
    }

    // ------------------------------------------------------ Applications en sourdine

    fun isMuted(context: Context, packageName: String): Boolean =
        (prefs(context).getStringSet(KEY_MUTED, emptySet()) ?: emptySet()).contains(packageName)

    @Synchronized
    fun setMuted(context: Context, packageName: String, muted: Boolean) {
        val set = HashSet<String>(prefs(context).getStringSet(KEY_MUTED, emptySet()) ?: emptySet())
        if (muted) set.add(packageName) else set.remove(packageName)
        prefs(context).edit().putStringSet(KEY_MUTED, set).apply()
    }

    /** Mémorise une application qui a envoyé une notification (entrée « paquet|nom »). */
    @Synchronized
    fun noteSeen(context: Context, packageName: String, label: String) {
        val current = prefs(context).getStringSet(KEY_SEEN, emptySet()) ?: emptySet()
        val entry = "$packageName|$label"
        if (entry in current) return
        val updated = HashSet<String>(current.filterNot { it.substringBefore('|') == packageName })
        updated.add(entry)
        while (updated.size > MAX_SEEN) updated.remove(updated.first())
        prefs(context).edit().putStringSet(KEY_SEEN, updated).apply()
    }

    /** Applications déjà vues, triées par nom : paires (paquet, nom affiché). */
    fun seenApps(context: Context): List<Pair<String, String>> =
        (prefs(context).getStringSet(KEY_SEEN, emptySet()) ?: emptySet())
            .map { it.substringBefore('|') to it.substringAfter('|') }
            .sortedBy { it.second.lowercase() }
}
