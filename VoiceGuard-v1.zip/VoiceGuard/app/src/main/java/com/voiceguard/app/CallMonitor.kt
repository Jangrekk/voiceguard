package com.voiceguard.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Surveille l'état du téléphone en temps réel (ça sonne, décroché, raccroché).
 *
 * - [onRinging] est appelé une seule fois par appel entrant, avec le nom (si le contact existe)
 *   et le numéro (si la permission du journal d'appels est accordée).
 * - [onStopped] est appelé quand l'appel est décroché ([TelephonyManager.CALL_STATE_OFFHOOK])
 *   ou terminé ([TelephonyManager.CALL_STATE_IDLE]).
 *
 * Android envoie souvent deux diffusions « RINGING » : l'une sans numéro, l'autre avec.
 * On attend donc brièvement le numéro avant d'annoncer l'appel.
 */
class CallMonitor(
    context: Context,
    private val onRinging: (CallerInfo) -> Unit,
    private val onStopped: (Int) -> Unit
) {
    companion object {
        private const val NUMBER_WAIT_MS = 1500L
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var registered = false
    private var ringing = false
    private var announced = false
    private var pendingNumber: String? = null
    private val fireRunnable = Runnable { fire() }

    private val receiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val received = intent ?: return
            if (received.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
            val state = received.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val number = received.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            handleState(state, number)
        }
    }

    fun start() {
        if (registered) return
        ContextCompat.registerReceiver(
            appContext,
            receiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        registered = true
    }

    fun stop() {
        if (!registered) return
        runCatching { appContext.unregisterReceiver(receiver) }
        registered = false
        main.removeCallbacks(fireRunnable)
        ringing = false
        announced = false
        pendingNumber = null
    }

    private fun handleState(state: String, number: String?) {
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (!ringing) {
                    ringing = true
                    announced = false
                    pendingNumber = null
                }
                if (!number.isNullOrBlank()) pendingNumber = number
                if (announced) return
                main.removeCallbacks(fireRunnable)
                main.postDelayed(fireRunnable, if (pendingNumber != null) 0L else NUMBER_WAIT_MS)
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK,
            TelephonyManager.EXTRA_STATE_IDLE -> {
                main.removeCallbacks(fireRunnable)
                ringing = false
                announced = false
                pendingNumber = null
                onStopped(
                    if (state == TelephonyManager.EXTRA_STATE_OFFHOOK) {
                        TelephonyManager.CALL_STATE_OFFHOOK
                    } else {
                        TelephonyManager.CALL_STATE_IDLE
                    }
                )
            }
        }
    }

    private fun fire() {
        if (!ringing || announced) return
        announced = true
        val number = pendingNumber
        if (number == null) {
            onRinging(CallerInfo(null, null))
            return
        }
        // La recherche dans les contacts se fait hors du thread principal.
        Thread {
            val name = lookupName(number)
            main.post { if (ringing) onRinging(CallerInfo(name, number)) }
        }.start()
    }

    private fun lookupName(number: String): String? {
        val granted = ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            appContext.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }
}
