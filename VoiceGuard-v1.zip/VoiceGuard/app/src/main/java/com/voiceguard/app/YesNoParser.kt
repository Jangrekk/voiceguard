package com.voiceguard.app

import java.text.Normalizer
import java.util.Locale

/** Interprète la réponse vocale de l'utilisateur : oui, non ou incompréhensible. */
object YesNoParser {

    enum class Answer { YES, NO, UNKNOWN }

    private val YES_WORDS = setOf(
        "oui", "ouais", "ouai", "yes", "yeah", "ok", "okay", "accord", "daccord", "dac",
        "volontiers", "affirmatif", "certainement", "absolument", "vas", "lis", "lire",
        "lisez", "sure",
        "waaw", "waw" // oui en wolof
    )

    private val NO_WORDS = setOf(
        "non", "no", "nope", "nan", "pas", "jamais", "laisse", "laissez", "annule",
        "annuler", "stop", "arrete", "arretez", "ignore", "ignorer", "tard", "negatif",
        "deedeet", "deet" // non en wolof
    )

    /** Teste les propositions du moteur de reconnaissance de la meilleure à la moins bonne. */
    fun parse(alternatives: List<String>): Answer {
        for (candidate in alternatives) {
            val answer = parseOne(candidate)
            if (answer != Answer.UNKNOWN) return answer
        }
        return Answer.UNKNOWN
    }

    fun parseOne(raw: String): Answer {
        val normalized = normalize(raw)
        val tokens = normalized.split(' ').filter { it.isNotEmpty() }
        // Une négation l'emporte toujours : « ne lis pas » doit rester un non.
        if (tokens.any { it in NO_WORDS }) return Answer.NO
        if (tokens.any { it in YES_WORDS }) return Answer.YES
        if (" ${tokens.joinToString(" ")} ".contains(" bien sur ")) return Answer.YES
        return Answer.UNKNOWN
    }

    /** Minuscules, sans accents, sans ponctuation ni apostrophes. */
    internal fun normalize(raw: String): String {
        val decomposed = Normalizer.normalize(raw.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        val out = StringBuilder()
        for (c in decomposed) {
            when {
                Character.getType(c) == Character.NON_SPACING_MARK.toInt() -> Unit
                c == '\'' || c == '’' -> Unit
                c.isLetter() -> out.append(c)
                else -> out.append(' ')
            }
        }
        return out.toString()
    }
}
