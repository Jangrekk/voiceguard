# VoiceGuard — Version 2 (notifications + appels entrants)

Assistant Android qui parle et écoute à votre place :

- **Notifications (V1)** : « Nouveau message WhatsApp. Voulez-vous que je vous le lise ? » → « Oui » →
  « Babacar : Bonjour, comment vas-tu ? ». Si vous dites « non », l'assistant s'arrête.
- **Appels entrants (V2)** : « Appel entrant de Babacar. Voulez-vous répondre ? » → vous décrochez ou
  refusez **à la voix**.

## Commandes vocales pour un appel

| Vous dites | Effet |
|---|---|
| « oui », « décroche », « réponds », « d'accord », « vas-y », « waaw » | l'appel est décroché |
| « refuse », « raccroche », « rejette », « coupe » | l'appel est refusé (raccroché) |
| « non », « ne réponds pas », « laisse », « déedéet » | rien : l'appel continue de sonner |
| autre chose / silence | l'assistant redemande une fois, puis laisse sonner |

« Non » ne raccroche volontairement pas : il faut dire « refuse » pour refuser. Une phrase ambiguë comme
« ne raccroche pas » est redemandée plutôt que devinée.

## Compiler et installer

**Avec Android Studio** : `File > Open` sur le dossier `VoiceGuard`, laissez Gradle se synchroniser,
puis `Run ▶` (ou `Build > Build APK(s)` : fichier dans `app/build/outputs/apk/debug/`).
Prérequis : Android 8.0 (API 26) ou plus, JDK 17.

**Depuis un téléphone, via GitHub Actions** : envoyez le zip dans le dépôt (le fichier de configuration
`.github/workflows/build.yml` le décompresse et compile l'APK), puis téléchargez l'artefact `VoiceGuard-apk`
dans l'onglet *Actions*. La version installée s'affiche en bas de l'écran d'accueil.

## Première utilisation

1. Activez l'interrupteur **Assistant vocal** : autorisez le **micro** (et les notifications sur Android 13+),
   puis activez **VoiceGuard** dans « Accès aux notifications » et revenez.
   - Si l'option est grisée (APK installé hors Play Store) : `Réglages > Applications > VoiceGuard >
     ⋮ > Autoriser les paramètres restreints`, puis recommencez.
2. Activez l'interrupteur **Appels entrants** et acceptez les permissions demandées :

   | Permission | Sert à | Si refusée |
   |---|---|---|
   | Téléphone (`READ_PHONE_STATE`) | détecter qu'un appel sonne | **fonction impossible** |
   | Journal d'appels (`READ_CALL_LOG`) | connaître le numéro de l'appelant (Android 9+) | « numéro masqué » |
   | Contacts (`READ_CONTACTS`) | dire le **nom** du contact | le numéro est lu à la place |
   | Répondre aux appels (`ANSWER_PHONE_CALLS`) | décrocher / refuser | l'appel est annoncé, mais vous devez décrocher à la main |

   Le bouton « Accorder les permissions d'appels » réapparaît tant qu'il en manque (il ouvre les réglages
   de l'application si Android ne montre plus la fenêtre).
3. Le bouton **Tester avec une fausse notification** vérifie tout le dialogue vocal des notifications.

## Architecture

| Fichier | Rôle |
|---|---|
| `VoiceGuardListenerService` | `NotificationListenerService` : reçoit les notifications, filtre (appels, médias, permanentes, résumés de groupe), supprime les doublons, transmet. |
| `NotificationDeduper` | Anti-doublons (même notification republiée : 2 min ; même contenu sous une autre clé : 10 s). |
| `AssistantService` | Service **au premier plan (type microphone)** : file d'attente, dialogue vocal. Un appel est **prioritaire** : il interrompt une lecture ; la notification non lue repart en tête de file. |
| `CallMonitor` | Écoute l'état du téléphone (sonne / décroché / raccroché), attend brièvement le numéro, cherche le nom dans les contacts. |
| `CallController` | Décroche (`acceptRingingCall`) ou refuse (`endCall`, Android 9+) via `TelecomManager`. |
| `CallCommandParser` / `YesNoParser` | Comprennent les réponses vocales (accents, négations, wolof). |
| `CallerInfo` | Phrase d'annonce : nom, sinon numéro lu par groupes de deux chiffres (indicatif 221 omis), sinon « numéro masqué ». |
| `VoiceEngine` | `TextToSpeech` (français) + `SpeechRecognizer` (fr-FR), focus audio, délais de sécurité, arrêt immédiat. |
| `EventLog` | Journal local (`filesDir/events.log`, 500 lignes). Ne contient **jamais** le texte des messages. |
| `MainActivity` / `LogActivity` | Écran d'accueil (réglages, permissions, version) et journal. |

Pendant une conversation, les notifications sont mises en attente et reprises 1,5 s après la fin de l'appel.
Un **appel en attente** (second appel pendant une conversation) est ignoré, pour ne pas couper la
communication en cours en décrochant.

## Limites connues

- **Micro pendant la sonnerie** : sur certains téléphones, Android ou le constructeur bloque le micro, ou la
  sonnerie couvre votre voix. L'écoute échoue alors et l'erreur est notée dans le journal ; l'appel continue
  de sonner normalement. Baissez la sonnerie ou mettez le téléphone en vibreur : c'est souvent bien plus fiable.
- **Refuser** n'est pas possible avant Android 9 (API 28) : l'appel est annoncé, vous raccrochez à la main.
- Le numéro de l'appelant n'est lisible qu'avec la permission « Journal d'appels ».
  *Google Play* restreint cette permission : sans importance pour un APK installé directement.
- La reconnaissance vocale utilise le service du téléphone (Google) : elle peut exiger Internet tant que le
  modèle français hors ligne n'est pas téléchargé (`Réglages > Langue > Saisie vocale Google`).
- Si le téléphone redémarre ou que le système tue l'application, ouvrez VoiceGuard une fois pour relancer
  l'assistant (Android interdit de démarrer un service micro en arrière-plan). Désactivez l'optimisation de
  batterie pour VoiceGuard pour plus de fiabilité.
- Seule la dernière notification d'une conversation est lue (pas l'historique).

## Tests

`./gradlew test` exécute les tests de `YesNoParser`, `CallCommandParser`, `CallerInfo` et
`NotificationDeduper` (logique pure, sans téléphone).

## Suite prévue

V3 : répondre vocalement aux messages, filtres par application ou contact, appels manqués.
