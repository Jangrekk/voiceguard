package com.voiceguard.app

import com.voiceguard.app.CallCommandParser.Command
import org.junit.Assert.assertEquals
import org.junit.Test

class CallCommandParserTest {

    @Test
    fun answer() {
        listOf("oui", "Oui !", "décroche", "réponds", "d'accord", "vas-y", "waaw")
            .forEach { assertEquals(it, Command.ANSWER, CallCommandParser.parseOne(it)) }
    }

    @Test
    fun reject() {
        listOf("refuse", "raccroche", "rejette l'appel", "non refuse")
            .forEach { assertEquals(it, Command.REJECT, CallCommandParser.parseOne(it)) }
    }

    @Test
    fun ignore() {
        listOf("non", "non merci", "ne réponds pas", "ne décroche pas", "déedéet")
            .forEach { assertEquals(it, Command.IGNORE, CallCommandParser.parseOne(it)) }
    }

    @Test
    fun unknown() {
        assertEquals(Command.UNKNOWN, CallCommandParser.parseOne("peut-être"))
        assertEquals(Command.UNKNOWN, CallCommandParser.parseOne("ne raccroche pas"))
        assertEquals(Command.UNKNOWN, CallCommandParser.parseOne(""))
    }
}
