# Règles ProGuard/R8 : aucune règle spécifique nécessaire pour la version 1.
