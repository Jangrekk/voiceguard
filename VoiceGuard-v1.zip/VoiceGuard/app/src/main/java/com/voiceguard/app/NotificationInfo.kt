package com.voiceguard.app

/** Informations utiles extraites d'une notification Android. */
data class NotificationInfo(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val isMessage: Boolean,
    val postTime: Long,
    /** Présent si la notification propose une réponse rapide (WhatsApp, SMS…). */
    val reply: ReplyTarget? = null
) {
    /** Phrase d'annonce posée avant de demander la permission de lire. */
    fun intro(): String =
        if (isMessage) "Nouveau message $appLabel. Voulez-vous que je vous le lise ?"
        else "Nouvelle notification $appLabel. Voulez-vous que je la lise ?"

    /** Contenu lu à voix haute si l'utilisateur répond oui. */
    fun spokenContent(): String = when {
        title.isNotBlank() && text.isNotBlank() -> "$title : $text"
        text.isNotBlank() -> text
        title.isNotBlank() -> title
        else -> "Cette notification ne contient pas de texte."
    }
}
