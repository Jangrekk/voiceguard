package com.voiceguard.app

import android.content.Context

/** Réglages locaux : uniquement l'état de l'assistant pour la version 1. */
object Prefs {
    private const val NAME = "voiceguard_prefs"
    private const val KEY_ENABLED = "assistant_enabled"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
    }
}
