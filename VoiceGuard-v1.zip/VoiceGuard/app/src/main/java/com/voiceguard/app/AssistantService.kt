package com.voiceguard.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Service au premier plan qui porte tout le dialogue vocal :
 * annonce, écoute de « oui » / « non », puis lecture éventuelle.
 *
 * Il est nécessaire car, depuis Android 11/12, seule une application avec un service
 * de premier plan de type « microphone » peut utiliser le micro lorsque l'écran est éteint
 * ou que l'application n'est pas affichée. Le NotificationListenerService lui transmet
 * simplement les notifications à traiter.
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.voiceguard.app.action.STOP"

        private const val CHANNEL_ID = "voiceguard_assistant"
        private const val NOTIFICATION_ID = 1001
        private const val MAX_QUEUE = 10
        private const val MAX_SPOKEN_CHARS = 600
        private const val GAP_BETWEEN_ITEMS_MS = 800L
        private const val LISTEN_DELAY_MS = 400L

        @Volatile
        private var instance: AssistantService? = null

        fun isRunning(): Boolean = instance != null

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, AssistantService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AssistantService::class.java))
        }

        /** Ajoute une notification à traiter. Renvoie false si l'assistant n'est pas lancé. */
        fun enqueue(info: NotificationInfo): Boolean {
            val service = instance ?: return false
            service.main.post { service.addToQueue(info) }
            return true
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<NotificationInfo>()
    private lateinit var voice: VoiceEngine
    private var voiceReady = false
    private var busy = false

    // ------------------------------------------------------------------- Cycle de vie

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        voice = VoiceEngine(this)
        voice.init { ok, detail ->
            voiceReady = ok
            EventLog.add(if (ok) "SYSTEME" else "ERREUR", detail)
            if (ok) processNext()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setEnabled(this, false)
            EventLog.add("SYSTEME", "Assistant désactivé depuis la notification")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
            EventLog.add("SYSTEME", "Assistant activé")
        } catch (e: Exception) {
            EventLog.add("ERREUR", "Démarrage du service vocal refusé (${e.javaClass.simpleName})")
            Prefs.setEnabled(this, false)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        queue.clear()
        if (::voice.isInitialized) voice.shutdown()
        EventLog.add("SYSTEME", "Assistant arrêté")
        super.onDestroy()
    }

    // ----------------------------------------------------------------------- File

    private fun addToQueue(info: NotificationInfo) {
        if (queue.size >= MAX_QUEUE) {
            val dropped = queue.removeFirst()
            EventLog.add("SYSTEME", "File pleine : notification ${dropped.appLabel} ignorée")
        }
        queue.addLast(info)
        EventLog.add("NOTIF", "${info.appLabel} — ${info.title.ifBlank { "(sans titre)" }}")
        processNext()
    }

    private fun processNext() {
        if (busy || !voiceReady || queue.isEmpty()) return
        busy = true
        val info = queue.removeFirst()
        handle(info) {
            busy = false
            main.postDelayed({ processNext() }, GAP_BETWEEN_ITEMS_MS)
        }
    }

    // --------------------------------------------------------------------- Dialogue

    private fun handle(info: NotificationInfo, done: () -> Unit) {
        voice.speak(info.intro()) { spoken ->
            if (!spoken) {
                EventLog.add("ERREUR", "Synthèse vocale : l'annonce a échoué")
                done()
                return@speak
            }
            ask(info, attempt = 1, done = done)
        }
    }

    private fun ask(info: NotificationInfo, attempt: Int, done: () -> Unit) {
        main.postDelayed({
            voice.listen { result ->
                when (result) {
                    is VoiceEngine.ListenResult.Heard -> when (YesNoParser.parse(result.alternatives)) {
                        YesNoParser.Answer.YES -> {
                            EventLog.add("REPONSE", "Oui")
                            readContent(info, done)
                        }
                        YesNoParser.Answer.NO -> {
                            EventLog.add("REPONSE", "Non — notification non lue")
                            done()
                        }
                        YesNoParser.Answer.UNKNOWN ->
                            retryOrGiveUp(info, attempt, done, "Réponse non comprise")
                    }
                    is VoiceEngine.ListenResult.NoSpeech ->
                        retryOrGiveUp(info, attempt, done, "Aucune réponse")
                    is VoiceEngine.ListenResult.Failure -> {
                        EventLog.add(
                            "ERREUR",
                            "Reconnaissance vocale : ${result.reason} (code ${result.code})"
                        )
                        voice.speak("La reconnaissance vocale est indisponible.") { done() }
                    }
                }
            }
        }, LISTEN_DELAY_MS)
    }

    private fun retryOrGiveUp(
        info: NotificationInfo,
        attempt: Int,
        done: () -> Unit,
        reason: String
    ) {
        if (attempt >= 2) {
            EventLog.add("REPONSE", "$reason — abandon")
            done()
            return
        }
        EventLog.add("REPONSE", "$reason — nouvelle tentative")
        voice.speak("Je n'ai pas compris. Dites oui ou non.") { ok ->
            if (ok) ask(info, attempt + 1, done) else done()
        }
    }

    private fun readContent(info: NotificationInfo, done: () -> Unit) {
        val raw = info.spokenContent()
        val text = if (raw.length > MAX_SPOKEN_CHARS) {
            raw.take(MAX_SPOKEN_CHARS) + "… message tronqué"
        } else raw
        voice.speak(text) { ok ->
            if (ok) EventLog.add("LECTURE", "${info.appLabel} lu à voix haute")
            else EventLog.add("ERREUR", "Échec de la lecture à voix haute")
            done()
        }
    }

    // ------------------------------------------------------------------ Notification

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification() = run {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            flags
        )
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_voice)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
