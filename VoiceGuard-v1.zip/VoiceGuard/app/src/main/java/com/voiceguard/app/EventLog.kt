package com.voiceguard.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Journal local simple : un fichier texte dans le stockage privé de l'application.
 * Le contenu des messages n'est jamais enregistré, seulement les événements
 * (application, expéditeur/titre, réponse de l'utilisateur, erreurs).
 */
object EventLog {
    private const val FILE_NAME = "events.log"
    private const val MAX_LINES = 500
    private const val TRIM_SLACK = 100

    private val lock = Any()
    private var file: File? = null
    private var lineCount = 0

    fun init(context: Context) {
        synchronized(lock) {
            if (file != null) return
            val f = File(context.applicationContext.filesDir, FILE_NAME)
            file = f
            lineCount = if (f.exists()) runCatching { f.readLines().size }.getOrDefault(0) else 0
        }
    }

    fun add(type: String, message: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE).format(Date())
        val line = "$stamp | $type | ${message.replace('\n', ' ')}"
        synchronized(lock) {
            val f = file ?: return
            try {
                f.appendText(line + "\n")
                lineCount++
                if (lineCount > MAX_LINES + TRIM_SLACK) trim(f)
            } catch (_: Exception) {
                // Le journal ne doit jamais faire planter l'application.
            }
        }
    }

    /** Événements du plus récent au plus ancien. */
    fun readAll(): List<String> = synchronized(lock) {
        val f = file
        if (f == null || !f.exists()) emptyList()
        else runCatching { f.readLines().asReversed() }.getOrDefault(emptyList())
    }

    fun clear() {
        synchronized(lock) {
            runCatching { file?.writeText("") }
            lineCount = 0
        }
    }

    private fun trim(f: File) {
        val kept = f.readLines().takeLast(MAX_LINES)
        f.writeText(kept.joinToString("\n", postfix = "\n"))
        lineCount = kept.size
    }
}
