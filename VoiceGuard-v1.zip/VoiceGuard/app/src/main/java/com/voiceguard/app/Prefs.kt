package com.voiceguard.app

import android.content.Context

/** Réglages locaux : état de l'assistant et de la fonction « appels entrants ». */
object Prefs {
    private const val NAME = "voiceguard_prefs"
    private const val KEY_ENABLED = "assistant_enabled"
    private const val KEY_CALLS = "calls_enabled"
    private const val KEY_CALL_PERM_ASKED = "call_permissions_asked"

    private fun prefs(context: Context) =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun isCallsEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_CALLS, false)

    fun setCallsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_CALLS, enabled).apply()
    }

    /** Vrai une fois que la fenêtre de permissions d'appels a été montrée au moins une fois. */
    fun wasCallPermissionAsked(context: Context): Boolean =
        prefs(context).getBoolean(KEY_CALL_PERM_ASKED, false)

    fun setCallPermissionAsked(context: Context, asked: Boolean) {
        prefs(context).edit().putBoolean(KEY_CALL_PERM_ASKED, asked).apply()
    }
}
