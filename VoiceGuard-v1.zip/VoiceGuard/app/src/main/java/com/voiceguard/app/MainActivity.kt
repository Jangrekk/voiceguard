package com.voiceguard.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var switchAssistant: MaterialSwitch
    private lateinit var textStatusAssistant: TextView
    private lateinit var textStatusNotif: TextView
    private lateinit var textStatusMic: TextView
    private lateinit var buttonNotifAccess: Button

    private val handler = Handler(Looper.getMainLooper())
    private var updatingUi = false
    private var pendingEnable = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (!hasMicPermission()) {
                pendingEnable = false
                toast(R.string.toast_mic_denied)
            } else if (pendingEnable) {
                pendingEnable = false
                tryEnableAssistant()
            }
            updateUi()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        switchAssistant = findViewById(R.id.switchAssistant)
        textStatusAssistant = findViewById(R.id.textStatusAssistant)
        textStatusNotif = findViewById(R.id.textStatusNotif)
        textStatusMic = findViewById(R.id.textStatusMic)
        buttonNotifAccess = findViewById(R.id.buttonNotifAccess)

        switchAssistant.setOnCheckedChangeListener { _, checked ->
            if (updatingUi) return@setOnCheckedChangeListener
            if (checked) tryEnableAssistant() else disableAssistant()
        }
        buttonNotifAccess.setOnClickListener { openNotificationAccessSettings() }
        findViewById<Button>(R.id.buttonTest).setOnClickListener { sendTestNotification() }
        findViewById<Button>(R.id.buttonLog).setOnClickListener {
            startActivity(Intent(this, LogActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Si l'utilisateur avait activé l'assistant mais que le processus a été arrêté
        // (redémarrage, économie d'énergie), on le relance maintenant que l'écran est visible.
        if (Prefs.isEnabled(this) && !AssistantService.isRunning()) {
            if (hasMicPermission() && isNotificationAccessGranted()) {
                AssistantService.start(this)
            } else {
                Prefs.setEnabled(this, false)
            }
        }
        updateUi()
        handler.postDelayed({ updateUi() }, 700)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------ Activation

    private fun tryEnableAssistant() {
        if (!hasMicPermission()) {
            pendingEnable = true
            setSwitch(false)
            permissionLauncher.launch(requiredPermissions())
            return
        }
        if (!isNotificationAccessGranted()) {
            setSwitch(false)
            toast(R.string.toast_need_notif_access)
            openNotificationAccessSettings()
            return
        }
        Prefs.setEnabled(this, true)
        AssistantService.start(this)
        handler.postDelayed({ updateUi() }, 700)
        updateUi()
    }

    private fun disableAssistant() {
        Prefs.setEnabled(this, false)
        AssistantService.stop(this)
        handler.postDelayed({ updateUi() }, 300)
        updateUi()
    }

    private fun sendTestNotification() {
        if (!AssistantService.isRunning()) {
            toast(R.string.toast_start_first)
            return
        }
        val now = System.currentTimeMillis()
        AssistantService.enqueue(
            NotificationInfo(
                key = "test-$now",
                packageName = "com.whatsapp",
                appLabel = "WhatsApp",
                title = "Babacar",
                text = "Bonjour, comment vas-tu ?",
                isMessage = true,
                postTime = now
            )
        )
        toast(R.string.toast_test_sent)
    }

    // ---------------------------------------------------------------- Interface

    private fun updateUi() {
        val running = AssistantService.isRunning()
        setSwitch(running)
        textStatusAssistant.setText(
            if (running) R.string.status_assistant_on else R.string.status_assistant_off
        )
        val notifOk = isNotificationAccessGranted()
        textStatusNotif.setText(if (notifOk) R.string.status_notif_ok else R.string.status_notif_ko)
        textStatusMic.setText(if (hasMicPermission()) R.string.status_mic_ok else R.string.status_mic_ko)
        buttonNotifAccess.visibility = if (notifOk) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun setSwitch(checked: Boolean) {
        updatingUi = true
        switchAssistant.isChecked = checked
        updatingUi = false
    }

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_LONG).show()

    // --------------------------------------------------------------- Permissions

    private fun hasMicPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }

    private fun isNotificationAccessGranted() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
