# VoiceGuard — Version 3 (notifications + appels + réponse vocale)

Assistant Android qui parle et écoute à votre place :

- **Notifications (V1)** : « Nouveau message WhatsApp. Voulez-vous que je vous le lise ? » → « Oui » →
  « Babacar : Bonjour, comment vas-tu ? ». Si vous dites « non », l'assistant s'arrête.
- **Appels entrants (V2)** : « Appel entrant de Babacar. Voulez-vous répondre ? » → vous décrochez ou
  refusez **à la voix**.
- **Réponse vocale (V3)** : après la lecture d'un message, « Voulez-vous répondre ? » → vous dictez, il
  relit, vous confirmez, il envoie. Vous choisissez aussi **quelles applications sont annoncées**.

## Répondre à un message (V3)

Déroulé : lecture du message → « Voulez-vous répondre ? » → « oui » → « Je vous écoute. Dictez votre
réponse. » → vous parlez (2 s de silence terminent la dictée) → « Vous avez dit : … Envoyer à Babacar ? »

| Vous dites | Effet |
|---|---|
| « envoie », « oui », « d'accord », « waaw » | le message est envoyé |
| « recommence », « refais », « corrige » | nouvelle dictée (3 essais au maximum) |
| « non », « annule », « ne l'envoie pas », « déedéet » | rien n'est envoyé |
| autre chose / silence | l'assistant redemande une fois, puis annule |

**Rien n'est jamais envoyé sans votre confirmation vocale.** Le texte dicté n'est pas écrit dans le journal.
La réponse part par l'action « Répondre » de la notification (comme si vous tapiez dans la barre de
notifications), donc elle ne marche que pour les applications qui la proposent (WhatsApp, Messages,
Telegram…) et tant que la notification est encore là. Interrupteur « Répondre aux messages à la voix » pour
désactiver ; aucune permission de plus n'est nécessaire.

## Choisir les applications annoncées (V3)

Bouton « Choisir les applications annoncées » : une application apparaît dans la liste après sa première
notification ; coupez son interrupteur pour qu'elle ne soit plus jamais annoncée ni lue.

## Commandes vocales pour un appel (V2)

| Vous dites | Effet |
|---|---|
| « oui », « décroche », « réponds », « d'accord », « vas-y », « waaw » | l'appel est décroché |
| « refuse », « raccroche », « rejette », « coupe » | l'appel est refusé (raccroché) |
| « non », « ne réponds pas », « laisse », « déedéet » | rien : l'appel continue de sonner |
| autre chose / silence | l'assistant redemande une fois, puis laisse sonner |

« Non » ne raccroche volontairement pas : il faut dire « refuse » pour refuser.

## Compiler et installer

**Avec Android Studio** : `File > Open` sur le dossier `VoiceGuard`, laissez Gradle se synchroniser,
puis `Run ▶` (ou `Build > Build APK(s)` : fichier dans `app/build/outputs/apk/debug/`).
Prérequis : Android 8.0 (API 26) ou plus, JDK 17.

**Depuis un téléphone, via GitHub Actions** : envoyez le zip dans le dépôt (le fichier de configuration
`.github/workflows/build.yml` le décompresse et compile l'APK), puis téléchargez l'artefact `VoiceGuard-apk`
dans l'onglet *Actions*. La version installée s'affiche en bas de l'écran d'accueil.

## Première utilisation

1. Activez l'interrupteur **Assistant vocal** : autorisez le **micro** (et les notifications sur Android 13+),
   puis activez **VoiceGuard** dans « Accès aux notifications » et revenez.
   - Si l'option est grisée (APK installé hors Play Store) : `Réglages > Applications > VoiceGuard >
     ⋮ > Autoriser les paramètres restreints`, puis recommencez.
2. (Facultatif) Activez **Appels entrants** et acceptez les permissions :

   | Permission | Sert à | Si refusée |
   |---|---|---|
   | Téléphone (`READ_PHONE_STATE`) | détecter qu'un appel sonne | **fonction impossible** |
   | Journal d'appels (`READ_CALL_LOG`) | connaître le numéro de l'appelant (Android 9+) | « numéro masqué » |
   | Contacts (`READ_CONTACTS`) | dire le **nom** du contact | le numéro est lu à la place |
   | Répondre aux appels (`ANSWER_PHONE_CALLS`) | décrocher / refuser | l'appel est annoncé, mais vous devez décrocher à la main |

3. Le bouton **Tester avec une fausse notification** vérifie le dialogue de lecture. Pour tester la réponse
   vocale, il faut un vrai message (WhatsApp, SMS) : la fausse notification n'a pas d'action « Répondre ».

## Architecture

| Fichier | Rôle |
|---|---|
| `VoiceGuardListenerService` | `NotificationListenerService` : reçoit les notifications, filtre (appels, médias, permanentes, résumés, applications en sourdine), supprime les doublons, repère l'action « Répondre », transmet. |
| `NotificationDeduper` | Anti-doublons (même notification republiée : 2 min ; même contenu sous une autre clé : 10 s). |
| `AssistantService` | Service **au premier plan (type microphone)** : file d'attente, dialogues vocaux (lecture, réponse, appel). Un appel est **prioritaire** : il interrompt une lecture ; la notification non lue repart en tête de file. |
| `ReplyTarget` / `ReplySender` | L'action « Répondre » d'une notification, et l'envoi du texte dicté par cette action. |
| `ReplyConfirmParser` | Comprend « envoie », « recommence », « annule » ; nettoie le texte dicté. |
| `CallMonitor` / `CallController` | État du téléphone et recherche du contact ; décrocher (`acceptRingingCall`) ou refuser (`endCall`, Android 9+). |
| `CallCommandParser` / `YesNoParser` / `CallerInfo` | Réponses vocales (accents, négations, wolof) et phrase d'annonce d'un appel. |
| `VoiceEngine` | `TextToSpeech` (français) + `SpeechRecognizer` (fr-FR, durée et silence réglables pour la dictée), focus audio, arrêt immédiat. |
| `Prefs` / `EventLog` | Réglages locaux ; journal local (500 lignes, jamais le texte des messages). |
| `MainActivity` / `AppsActivity` / `LogActivity` | Accueil, choix des applications, journal. |

Pendant une conversation, les notifications sont mises en attente et reprises 1,5 s après la fin de l'appel.
Un **appel en attente** est ignoré, pour ne pas couper la communication en cours en décrochant.

## Limites connues

- **Dictée** : la qualité dépend de la reconnaissance vocale du téléphone. Elle est relue avant l'envoi
  justement pour que vous puissiez corriger. Pas de ponctuation dictée (« virgule », « point ») dans cette version.
- **Réponse à un groupe WhatsApp** : elle part dans le groupe ; l'assistant dit « Envoyer à <nom du groupe> ? »
  avant d'envoyer, écoutez bien ce nom.
- **Micro pendant la sonnerie** : sur certains téléphones, le micro est bloqué ou la sonnerie couvre votre voix.
  L'erreur est notée dans le journal ; l'appel sonne normalement. Le vibreur améliore souvent les choses.
- **Refuser un appel** n'est pas possible avant Android 9 (API 28).
- Le numéro de l'appelant demande la permission « Journal d'appels » (restreinte sur Google Play, sans
  importance pour un APK installé directement).
- La reconnaissance vocale utilise le service du téléphone (Google) : elle peut exiger Internet tant que le
  modèle français hors ligne n'est pas téléchargé (`Réglages > Langue > Saisie vocale Google`).
- Si le téléphone redémarre ou que le système tue l'application, ouvrez VoiceGuard une fois pour relancer
  l'assistant (Android interdit de démarrer un service micro en arrière-plan). Désactivez l'optimisation de
  batterie pour VoiceGuard pour plus de fiabilité.
- Seule la dernière notification d'une conversation est lue (pas l'historique).

## Tests

`./gradlew test` exécute les tests de `YesNoParser`, `CallCommandParser`, `CallerInfo`, `ReplyConfirmParser`
et `NotificationDeduper` (logique pure, sans téléphone).

## Suite possible

V4 : filtres par contact, appels manqués, lecture automatique des contacts favoris.
