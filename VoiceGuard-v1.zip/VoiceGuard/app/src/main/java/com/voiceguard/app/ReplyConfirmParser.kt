package com.voiceguard.app

/**
 * Interprète la réponse vocale après la relecture d'un message dicté :
 *  - « oui », « envoie »                    → envoyer ;
 *  - « recommence », « refais », « corrige » → dicter de nouveau ;
 *  - « non », « annule », « ne l'envoie pas » → annuler.
 */
object ReplyConfirmParser {

    enum class Command { SEND, REDO, CANCEL, UNKNOWN }

    private val SEND_WORDS = setOf(
        "oui", "ouais", "ouai", "yes", "ok", "okay", "accord", "daccord", "parfait", "valide",
        "envoie", "envoies", "envoyer", "envoyez", "vas", "go",
        "waaw", "waw" // oui en wolof
    )

    private val REDO_WORDS = setOf(
        "recommence", "recommencer", "recommencez", "refais", "refaire", "refaites",
        "corrige", "corriger", "autre"
    )

    private val CANCEL_WORDS = setOf(
        "non", "no", "nope", "nan", "pas", "jamais", "annule", "annuler", "annulez",
        "laisse", "laissez", "stop", "abandonne",
        "deedeet", "deet" // non en wolof
    )

    fun parse(alternatives: List<String>): Command {
        for (candidate in alternatives) {
            val command = parseOne(candidate)
            if (command != Command.UNKNOWN) return command
        }
        return Command.UNKNOWN
    }

    fun parseOne(raw: String): Command {
        val tokens = YesNoParser.normalize(raw).split(' ').filter { it.isNotEmpty() }
        val negated = tokens.any { it == "pas" || it == "jamais" }
        // « non, recommence » veut dire recommencer ; « ne recommence pas » veut dire annuler.
        if (!negated && tokens.any { it in REDO_WORDS }) return Command.REDO
        if (tokens.any { it in CANCEL_WORDS }) return Command.CANCEL
        if (tokens.any { it in SEND_WORDS }) return Command.SEND
        return Command.UNKNOWN
    }
}

/** Nettoyage du texte dicté avant relecture et envoi. */
object ReplyText {
    fun clean(raw: String): String {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        return if (text.isEmpty()) text else text.replaceFirstChar { it.uppercase() }
    }
}
