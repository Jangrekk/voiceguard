package com.voiceguard.app

/**
 * Évite d'annoncer deux fois la même notification.
 *
 * Android (et WhatsApp en particulier) republie souvent une notification identique
 * lors d'une mise à jour. Deux fenêtres glissantes sont utilisées :
 *  - même clé de notification + même contenu : 2 minutes ;
 *  - même contenu sous une autre clé (ex. résumé de groupe) : 10 secondes.
 */
object NotificationDeduper {
    private const val KEY_WINDOW_MS = 120_000L
    private const val CONTENT_WINDOW_MS = 10_000L

    private val lock = Any()
    private val byKey = HashMap<String, Long>()
    private val byContent = HashMap<String, Long>()

    fun isDuplicate(
        key: String,
        packageName: String,
        title: String,
        text: String,
        now: Long = System.currentTimeMillis()
    ): Boolean = synchronized(lock) {
        purge(now)
        val content = "$packageName|$title|$text"
        val keyed = "$key|$content"
        val duplicate = isRecent(byKey, keyed, now, KEY_WINDOW_MS) ||
            isRecent(byContent, content, now, CONTENT_WINDOW_MS)
        // Fenêtre glissante : on rafraîchit l'horodatage même pour un doublon.
        byKey[keyed] = now
        byContent[content] = now
        duplicate
    }

    private fun isRecent(map: Map<String, Long>, id: String, now: Long, window: Long): Boolean {
        val last = map[id] ?: return false
        return now - last <= window
    }

    private fun purge(now: Long) {
        byKey.entries.removeAll { now - it.value > KEY_WINDOW_MS }
        byContent.entries.removeAll { now - it.value > KEY_WINDOW_MS }
    }
}
