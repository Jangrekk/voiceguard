package com.voiceguard.app

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle

/** Envoie un texte comme réponse rapide à une notification, comme si vous l'aviez tapé dedans. */
object ReplySender {

    fun send(context: Context, target: ReplyTarget, text: String): Boolean {
        val input = target.remoteInputs.firstOrNull { it.allowFreeFormInput } ?: return false
        val fill = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        val results = Bundle().apply { putCharSequence(input.resultKey, text) }
        RemoteInput.addResultsToIntent(target.remoteInputs, fill, results)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            RemoteInput.setResultsSource(fill, RemoteInput.SOURCE_FREE_FORM_INPUT)
        }
        return try {
            target.pendingIntent.send(context, 0, fill)
            true
        } catch (e: PendingIntent.CanceledException) {
            // La notification a disparu ou a été remplacée entre-temps.
            false
        } catch (e: Exception) {
            false
        }
    }
}
