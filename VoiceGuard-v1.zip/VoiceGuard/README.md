# VoiceGuard — Version 1 (MVP notifications)

Assistant Android qui détecte les nouvelles notifications, **demande à voix haute** si vous voulez
les entendre, écoute votre réponse (« oui » / « non ») puis lit le contenu si vous acceptez.

> Exemple : « Nouveau message WhatsApp. Voulez-vous que je vous le lise ? » → « Oui » →
> « Babacar : Bonjour, comment vas-tu ? ». Si vous dites « non », l'assistant s'arrête.

## Compiler et installer

1. Installez **Android Studio** (version récente, Koala ou plus).
2. `File > Open` et choisissez le dossier `VoiceGuard`. Laissez la synchronisation Gradle se terminer
   (Android Studio télécharge Gradle 8.7 et le SDK Android 34 si besoin).
3. Branchez votre téléphone (débogage USB activé) ou lancez un émulateur avec Google Play, puis `Run ▶`.
   Pour obtenir un APK : `Build > Build APK(s)` (fichier dans `app/build/outputs/apk/debug/`).

Prérequis : Android 8.0 (API 26) ou plus. JDK 17 (fourni avec Android Studio).

## Première utilisation

1. Ouvrez VoiceGuard et activez l'interrupteur **Assistant vocal**.
2. Autorisez le **micro** (et les notifications sur Android 13+).
3. L'application ouvre les réglages : activez **VoiceGuard** dans « Accès aux notifications », puis revenez.
   - Si l'APK est installé hors Play Store et que l'option est grisée : `Réglages > Applications > VoiceGuard >
     ⋮ > Autoriser les paramètres restreints`, puis recommencez.
4. Réactivez l'interrupteur. Un bouton **Tester avec une fausse notification** permet de vérifier tout le
   dialogue vocal sans attendre un vrai message.

## Architecture

| Fichier | Rôle |
|---|---|
| `VoiceGuardListenerService` | `NotificationListenerService` : reçoit les notifications, filtre (appels, médias, notifications permanentes, résumés de groupe, VoiceGuard lui-même), supprime les doublons, transmet. |
| `NotificationDeduper` | Anti-doublons (même notification republiée : 2 min ; même contenu sous une autre clé : 10 s). |
| `AssistantService` | Service **au premier plan (type microphone)** : file d'attente, annonce, écoute, lecture. Nécessaire pour que le micro fonctionne écran éteint sous Android 11+. |
| `VoiceEngine` | `TextToSpeech` (français) + `SpeechRecognizer` (fr-FR), focus audio, délais de sécurité. |
| `YesNoParser` | Comprend oui/non (accents, « d'accord », « ne lis pas » = non, et « waaw » / « déedéet » en wolof). |
| `EventLog` | Journal local (`filesDir/events.log`, 500 lignes max). Ne contient **jamais** le texte des messages. |
| `MainActivity` / `LogActivity` | Écran d'accueil et journal. |

Gestion des erreurs : moteur vocal absent, voix française manquante, micro refusé, reconnaissance
indisponible, aucune réponse (une relance puis abandon), service refusé par le système, file pleine (10 max).

## Limites connues de la V1

- La reconnaissance vocale utilise le service du téléphone (Google) : elle peut exiger Internet selon
  l'appareil, tant que le modèle français hors ligne n'est pas téléchargé
  (`Réglages > Langue > Saisie vocale Google > Reconnaissance hors connexion`).
- Si le téléphone redémarre ou que le système tue l'application, ouvrez VoiceGuard une fois : l'assistant
  se relance (Android interdit de démarrer un service micro en arrière-plan). Désactivez l'optimisation de
  batterie pour VoiceGuard pour plus de fiabilité.
- Seule la dernière notification d'une conversation est lue (pas l'historique complet).
- Pendant un appel téléphonique, le micro est occupé : l'écoute échouera et sera notée dans le journal.

## Tests

`./gradlew test` (ou clic droit sur `app/src/test` dans Android Studio) exécute les tests de `YesNoParser`
et `NotificationDeduper`.

## Suite prévue

V2 et suivantes : lecture/réponse vocale, filtres par application ou contact, appels, etc.
