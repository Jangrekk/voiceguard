package com.voiceguard.app

import org.junit.Assert.assertEquals
import org.junit.Test

class YesNoParserTest {

    @Test
    fun recognisesYes() {
        listOf("oui", "Oui !", "ouais", "d'accord", "Vas-y", "OK", "bien sûr", "waaw")
            .forEach { assertEquals(it, YesNoParser.Answer.YES, YesNoParser.parseOne(it)) }
    }

    @Test
    fun recognisesNo() {
        listOf("non", "Non merci", "ne lis pas", "laisse tomber", "pas maintenant", "déedéet")
            .forEach { assertEquals(it, YesNoParser.Answer.NO, YesNoParser.parseOne(it)) }
    }

    @Test
    fun unknownWhenAmbiguous() {
        assertEquals(YesNoParser.Answer.UNKNOWN, YesNoParser.parseOne("peut-être"))
        assertEquals(YesNoParser.Answer.UNKNOWN, YesNoParser.parseOne(""))
    }

    @Test
    fun usesFirstUsefulAlternative() {
        assertEquals(YesNoParser.Answer.YES, YesNoParser.parse(listOf("blabla", "oui", "non")))
    }
}
