package com.voiceguard.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LogActivity : AppCompatActivity() {

    private lateinit var textLog: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)
        textLog = findViewById(R.id.textLog)
        findViewById<Button>(R.id.buttonRefresh).setOnClickListener { refresh() }
        findViewById<Button>(R.id.buttonClear).setOnClickListener {
            EventLog.clear()
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val lines = EventLog.readAll()
        textLog.text = if (lines.isEmpty()) getString(R.string.log_empty) else lines.joinToString("\n")
    }
}
