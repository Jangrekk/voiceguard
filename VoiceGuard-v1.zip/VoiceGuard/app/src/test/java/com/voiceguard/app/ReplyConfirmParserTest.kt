package com.voiceguard.app

import com.voiceguard.app.ReplyConfirmParser.Command
import org.junit.Assert.assertEquals
import org.junit.Test

class ReplyConfirmParserTest {

    @Test
    fun send() {
        listOf("oui", "envoie", "Envoie-le", "d'accord", "vas-y", "waaw", "oui envoie")
            .forEach { assertEquals(it, Command.SEND, ReplyConfirmParser.parseOne(it)) }
    }

    @Test
    fun redo() {
        listOf("recommence", "non recommence", "refais", "corrige")
            .forEach { assertEquals(it, Command.REDO, ReplyConfirmParser.parseOne(it)) }
    }

    @Test
    fun cancel() {
        listOf("non", "annule", "ne l'envoie pas", "laisse tomber", "ne recommence pas", "déedéet")
            .forEach { assertEquals(it, Command.CANCEL, ReplyConfirmParser.parseOne(it)) }
    }

    @Test
    fun unknown() {
        assertEquals(Command.UNKNOWN, ReplyConfirmParser.parseOne("peut-être"))
        assertEquals(Command.UNKNOWN, ReplyConfirmParser.parseOne(""))
    }

    @Test
    fun usesFirstUsefulAlternative() {
        assertEquals(Command.SEND, ReplyConfirmParser.parse(listOf("blabla", "envoie", "annule")))
    }

    @Test
    fun cleansDictatedText() {
        assertEquals("Bonjour comment vas-tu", ReplyText.clean("  bonjour   comment vas-tu "))
        assertEquals("", ReplyText.clean("   "))
    }
}
