package com.voiceguard.app

import android.app.PendingIntent
import android.app.RemoteInput

/**
 * Action « Répondre » d'une notification de message : l'intent à déclencher
 * et les champs de saisie qu'elle attend (c'est ainsi que WhatsApp, Messages, Telegram… reçoivent
 * une réponse rapide depuis la barre de notifications).
 */
class ReplyTarget(
    val pendingIntent: PendingIntent,
    val remoteInputs: Array<RemoteInput>
)
