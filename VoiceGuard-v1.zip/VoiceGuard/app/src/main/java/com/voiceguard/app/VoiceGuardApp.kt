package com.voiceguard.app

import android.app.Application

class VoiceGuardApp : Application() {
    override fun onCreate() {
        super.onCreate()
        EventLog.init(this)
    }
}
