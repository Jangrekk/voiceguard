package com.voiceguard.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Service au premier plan qui porte tout le dialogue vocal :
 *  - notifications : annonce, écoute de « oui » / « non », puis lecture éventuelle ;
 *  - appels entrants (V2) : annonce de l'appelant, puis « oui » décroche, « refuse » raccroche.
 *
 * Il est nécessaire car, depuis Android 11/12, seule une application avec un service
 * de premier plan de type « microphone » peut utiliser le micro lorsque l'écran est éteint
 * ou que l'application n'est pas affichée.
 *
 * Chaque dialogue appartient à une « session » : si un appel interrompt une lecture,
 * le numéro de session change et les rappels de l'ancien dialogue sont ignorés.
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.voiceguard.app.action.STOP"

        private const val CHANNEL_ID = "voiceguard_assistant"
        private const val NOTIFICATION_ID = 1001
        private const val MAX_QUEUE = 10
        private const val MAX_SPOKEN_CHARS = 600
        private const val GAP_BETWEEN_ITEMS_MS = 800L
        private const val LISTEN_DELAY_MS = 400L
        private const val RESUME_AFTER_CALL_MS = 1500L

        @Volatile
        private var instance: AssistantService? = null

        fun isRunning(): Boolean = instance != null

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, AssistantService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AssistantService::class.java))
        }

        /** Ajoute une notification à traiter. Renvoie false si l'assistant n'est pas lancé. */
        fun enqueue(info: NotificationInfo): Boolean {
            val service = instance ?: return false
            service.main.post { service.addToQueue(info) }
            return true
        }

        /** À appeler quand l'utilisateur active/désactive les appels ou accorde une permission. */
        fun refreshCalls() {
            val service = instance ?: return
            service.main.post { service.setupCallMonitor() }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<NotificationInfo>()
    private lateinit var voice: VoiceEngine
    private var voiceReady = false
    private var busy = false

    /** Notification en cours de dialogue : remise en file si un appel l'interrompt avant lecture. */
    private var current: NotificationInfo? = null
    private var currentRead = false

    /** Numéro du dialogue en cours ; il change dès qu'un dialogue est interrompu. */
    private var session = 0
    private var callState = TelephonyManager.CALL_STATE_IDLE
    private var callMonitor: CallMonitor? = null

    // ------------------------------------------------------------------- Cycle de vie

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        voice = VoiceEngine(this)
        voice.init { ok, detail ->
            voiceReady = ok
            EventLog.add(if (ok) "SYSTEME" else "ERREUR", detail)
            if (ok) processNext()
        }
        setupCallMonitor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setEnabled(this, false)
            EventLog.add("SYSTEME", "Assistant désactivé depuis la notification")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
            EventLog.add("SYSTEME", "Assistant activé")
        } catch (e: Exception) {
            EventLog.add("ERREUR", "Démarrage du service vocal refusé (${e.javaClass.simpleName})")
            Prefs.setEnabled(this, false)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        callMonitor?.stop()
        callMonitor = null
        queue.clear()
        if (::voice.isInitialized) voice.shutdown()
        EventLog.add("SYSTEME", "Assistant arrêté")
        super.onDestroy()
    }

    // ----------------------------------------------------------------------- File

    private fun addToQueue(info: NotificationInfo) {
        if (queue.size >= MAX_QUEUE) {
            val dropped = queue.removeFirst()
            EventLog.add("SYSTEME", "File pleine : notification ${dropped.appLabel} ignorée")
        }
        queue.addLast(info)
        EventLog.add("NOTIF", "${info.appLabel} — ${info.title.ifBlank { "(sans titre)" }}")
        processNext()
    }

    private fun processNext() {
        // Pas de lecture de notification pendant qu'un appel sonne ou est en cours.
        if (busy || !voiceReady || queue.isEmpty()) return
        if (callState != TelephonyManager.CALL_STATE_IDLE) {
            // Si la fin de l'appel nous a échappé, on se recale sur l'état réel du téléphone.
            if (realCallState() != TelephonyManager.CALL_STATE_IDLE) return
            callState = TelephonyManager.CALL_STATE_IDLE
        }
        busy = true
        val info = queue.removeFirst()
        current = info
        currentRead = false
        handle(info) {
            busy = false
            current = null
            main.postDelayed({ processNext() }, GAP_BETWEEN_ITEMS_MS)
        }
    }

    @Suppress("DEPRECATION")
    private fun realCallState(): Int = try {
        (getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).callState
    } catch (e: Exception) {
        TelephonyManager.CALL_STATE_IDLE
    }

    // ------------------------------------------------------- Dialogue : notifications

    private fun handle(info: NotificationInfo, done: () -> Unit) {
        val s = session
        voice.speak(info.intro()) { spoken ->
            if (s != session) return@speak
            if (!spoken) {
                EventLog.add("ERREUR", "Synthèse vocale : l'annonce a échoué")
                done()
                return@speak
            }
            ask(info, attempt = 1, s = s, done = done)
        }
    }

    private fun ask(info: NotificationInfo, attempt: Int, s: Int, done: () -> Unit) {
        main.postDelayed({
            if (s != session) return@postDelayed
            voice.listen { result ->
                if (s != session) return@listen
                when (result) {
                    is VoiceEngine.ListenResult.Heard -> when (YesNoParser.parse(result.alternatives)) {
                        YesNoParser.Answer.YES -> {
                            EventLog.add("REPONSE", "Oui")
                            currentRead = true
                            readContent(info, s, done)
                        }
                        YesNoParser.Answer.NO -> {
                            EventLog.add("REPONSE", "Non — notification non lue")
                            done()
                        }
                        YesNoParser.Answer.UNKNOWN ->
                            retryOrGiveUp(info, attempt, s, done, "Réponse non comprise")
                    }
                    is VoiceEngine.ListenResult.NoSpeech ->
                        retryOrGiveUp(info, attempt, s, done, "Aucune réponse")
                    is VoiceEngine.ListenResult.Failure -> {
                        EventLog.add(
                            "ERREUR",
                            "Reconnaissance vocale : ${result.reason} (code ${result.code})"
                        )
                        voice.speak("La reconnaissance vocale est indisponible.") {
                            if (s == session) done()
                        }
                    }
                }
            }
        }, LISTEN_DELAY_MS)
    }

    private fun retryOrGiveUp(
        info: NotificationInfo,
        attempt: Int,
        s: Int,
        done: () -> Unit,
        reason: String
    ) {
        if (attempt >= 2) {
            EventLog.add("REPONSE", "$reason — abandon")
            done()
            return
        }
        EventLog.add("REPONSE", "$reason — nouvelle tentative")
        voice.speak("Je n'ai pas compris. Dites oui ou non.") { ok ->
            if (s != session) return@speak
            if (ok) ask(info, attempt + 1, s, done) else done()
        }
    }

    private fun readContent(info: NotificationInfo, s: Int, done: () -> Unit) {
        val raw = info.spokenContent()
        val text = if (raw.length > MAX_SPOKEN_CHARS) {
            raw.take(MAX_SPOKEN_CHARS) + "… message tronqué"
        } else raw
        voice.speak(text) { ok ->
            if (s != session) return@speak
            if (ok) EventLog.add("LECTURE", "${info.appLabel} lu à voix haute")
            else EventLog.add("ERREUR", "Échec de la lecture à voix haute")
            done()
        }
    }

    // ------------------------------------------------------- Appels entrants (V2)

    /** Active ou coupe la surveillance des appels selon le réglage et la permission. */
    private fun setupCallMonitor() {
        callMonitor?.stop()
        callMonitor = null
        if (callState != TelephonyManager.CALL_STATE_IDLE) {
            callState = TelephonyManager.CALL_STATE_IDLE
            interruptDialog()
            busy = false
        }
        if (!Prefs.isCallsEnabled(this)) return
        val allowed = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED
        if (!allowed) {
            EventLog.add("ERREUR", "Permission téléphone manquante : appels non surveillés")
            return
        }
        callMonitor = CallMonitor(this, ::onIncomingCall, ::onCallStopped).also { it.start() }
        EventLog.add("SYSTEME", "Surveillance des appels activée")
    }

    private fun onIncomingCall(caller: CallerInfo) {
        if (callState == TelephonyManager.CALL_STATE_OFFHOOK) {
            // Appel en attente pendant une conversation : décrocher couperait la communication en cours.
            EventLog.add("APPEL", "Appel en attente ignoré (conversation en cours)")
            return
        }
        callState = TelephonyManager.CALL_STATE_RINGING
        // Un appel est prioritaire : il interrompt toute lecture en cours.
        interruptDialog()
        val s = session
        busy = true
        EventLog.add("APPEL", "Appel entrant — ${caller.name ?: "numéro non enregistré"}")
        if (!voiceReady) return
        voice.speak(caller.spoken() + " Voulez-vous répondre ?") { spoken ->
            if (s != session) return@speak
            if (!spoken) {
                EventLog.add("ERREUR", "Synthèse vocale : l'annonce de l'appel a échoué")
                return@speak
            }
            askCall(s, attempt = 1)
        }
    }

    /** Appelé quand l'appel est décroché (à la main ou par nous) ou terminé. */
    private fun onCallStopped(state: Int) {
        callState = state
        interruptDialog()
        busy = false
        if (state == TelephonyManager.CALL_STATE_IDLE) {
            main.postDelayed({ processNext() }, RESUME_AFTER_CALL_MS)
        }
    }

    /**
     * Coupe la voix et abandonne le dialogue en cours (ses rappels deviennent sans effet).
     * Une notification pas encore lue repart en tête de file pour ne jamais être perdue.
     */
    private fun interruptDialog() {
        session++
        voice.stopAll()
        current?.let { if (!currentRead) queue.addFirst(it) }
        current = null
    }

    private fun askCall(s: Int, attempt: Int) {
        main.postDelayed({
            if (s != session) return@postDelayed
            voice.listen { result ->
                if (s != session) return@listen
                when (result) {
                    is VoiceEngine.ListenResult.Heard -> when (CallCommandParser.parse(result.alternatives)) {
                        CallCommandParser.Command.ANSWER -> answerCall()
                        CallCommandParser.Command.REJECT -> rejectCall()
                        CallCommandParser.Command.IGNORE ->
                            EventLog.add("REPONSE", "Non — l'appel continue de sonner")
                        CallCommandParser.Command.UNKNOWN ->
                            retryCall(s, attempt, "Réponse non comprise")
                    }
                    is VoiceEngine.ListenResult.NoSpeech -> retryCall(s, attempt, "Aucune réponse")
                    is VoiceEngine.ListenResult.Failure -> EventLog.add(
                        "ERREUR",
                        "Reconnaissance vocale : ${result.reason} (code ${result.code})"
                    )
                }
            }
        }, LISTEN_DELAY_MS)
    }

    private fun retryCall(s: Int, attempt: Int, reason: String) {
        if (attempt >= 2) {
            EventLog.add("REPONSE", "$reason — abandon, l'appel continue de sonner")
            return
        }
        EventLog.add("REPONSE", "$reason — nouvelle tentative")
        voice.speak("Je n'ai pas compris. Dites oui pour répondre, ou refuse.") { ok ->
            if (s != session) return@speak
            if (ok) askCall(s, attempt + 1)
        }
    }

    private fun answerCall() {
        EventLog.add("REPONSE", "Décrocher")
        if (CallController.answer(this)) {
            EventLog.add("APPEL", "Appel décroché à la voix")
        } else {
            EventLog.add("ERREUR", "Décrocher impossible (permission « répondre aux appels » ?)")
            voice.speak("Je ne peux pas décrocher. Faites-le à la main.") { }
        }
    }

    private fun rejectCall() {
        EventLog.add("REPONSE", "Refuser")
        if (CallController.reject(this)) {
            EventLog.add("APPEL", "Appel refusé à la voix")
        } else {
            EventLog.add("ERREUR", "Refuser impossible (permission « répondre aux appels » ?)")
            voice.speak("Je ne peux pas refuser l'appel. Faites-le à la main.") { }
        }
    }

    // ------------------------------------------------------------------ Notification

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification() = run {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            flags
        )
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_voice)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
