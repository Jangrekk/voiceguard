package com.voiceguard.app

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch

/** Liste des applications déjà vues : un interrupteur par application (coupé = jamais annoncée). */
class AppsActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var textEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        list = findViewById(R.id.listApps)
        textEmpty = findViewById(R.id.textAppsEmpty)
    }

    override fun onResume() {
        super.onResume()
        populate()
    }

    private fun populate() {
        list.removeAllViews()
        val apps = Prefs.seenApps(this)
        textEmpty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        val padding = (12 * resources.displayMetrics.density).toInt()
        for ((packageName, label) in apps) {
            val row = MaterialSwitch(this)
            row.text = label
            row.isChecked = !Prefs.isMuted(this, packageName)
            row.setPadding(0, padding, 0, padding)
            row.setOnCheckedChangeListener { _, checked ->
                Prefs.setMuted(this, packageName, !checked)
            }
            list.addView(
                row,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }
}
