package com.voiceguard.app

import org.junit.Assert.assertEquals
import org.junit.Test

class CallerInfoTest {

    @Test
    fun announcesNameWhenKnown() {
        assertEquals("Appel entrant de Babacar.", CallerInfo("Babacar", "+221771234567").spoken())
    }

    @Test
    fun announcesNumberWhenNameUnknown() {
        assertEquals(
            "Appel entrant du numéro 77 12 34 56 7.",
            CallerInfo(null, "+221 77 123 45 67").spoken()
        )
    }

    @Test
    fun announcesHiddenNumber() {
        assertEquals("Appel entrant. Numéro masqué.", CallerInfo(null, null).spoken())
    }

    @Test
    fun speakableNumberKeepsForeignPrefix() {
        // Hors Sénégal l'indicatif est conservé ; les chiffres sont regroupés par deux.
        assertEquals("33 61 23 45 67 8", speakableNumber("+33 6 12 34 56 78"))
    }

    @Test
    fun speakableNumberDropsSenegalPrefix() {
        assertEquals("77 12 34 56 7", speakableNumber("+221771234567"))
    }
}
