package com.voiceguard.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    companion object {
        /** La première est indispensable ; les autres améliorent l'expérience. */
        private val CALL_PERMISSIONS = arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
    }

    private lateinit var switchAssistant: MaterialSwitch
    private lateinit var textStatusAssistant: TextView
    private lateinit var textStatusNotif: TextView
    private lateinit var textStatusMic: TextView
    private lateinit var buttonNotifAccess: Button
    private lateinit var switchCalls: MaterialSwitch
    private lateinit var textStatusCalls: TextView
    private lateinit var buttonCallPermissions: Button

    private val handler = Handler(Looper.getMainLooper())
    private var updatingUi = false
    private var pendingEnable = false
    private var pendingEnableCalls = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
                pendingEnable = false
                toast(R.string.toast_mic_denied)
            } else if (pendingEnable) {
                pendingEnable = false
                tryEnableAssistant()
            }
            updateUi()
        }

    private val callPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onCallPermissionResult()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        switchAssistant = findViewById(R.id.switchAssistant)
        textStatusAssistant = findViewById(R.id.textStatusAssistant)
        textStatusNotif = findViewById(R.id.textStatusNotif)
        textStatusMic = findViewById(R.id.textStatusMic)
        buttonNotifAccess = findViewById(R.id.buttonNotifAccess)
        switchCalls = findViewById(R.id.switchCalls)
        textStatusCalls = findViewById(R.id.textStatusCalls)
        buttonCallPermissions = findViewById(R.id.buttonCallPermissions)

        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            null
        }
        findViewById<TextView>(R.id.textVersion).text = getString(R.string.version_label, version ?: "?")

        switchAssistant.setOnCheckedChangeListener { _, checked ->
            if (updatingUi) return@setOnCheckedChangeListener
            if (checked) tryEnableAssistant() else disableAssistant()
        }
        switchCalls.setOnCheckedChangeListener { _, checked ->
            if (updatingUi) return@setOnCheckedChangeListener
            if (checked) enableCalls() else disableCalls()
        }
        buttonNotifAccess.setOnClickListener { openNotificationAccessSettings() }
        buttonCallPermissions.setOnClickListener { requestMissingCallPermissions() }
        findViewById<Button>(R.id.buttonTest).setOnClickListener { sendTestNotification() }
        findViewById<Button>(R.id.buttonLog).setOnClickListener {
            startActivity(Intent(this, LogActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Si l'utilisateur avait activé l'assistant mais que le processus a été arrêté
        // (redémarrage, économie d'énergie), on le relance maintenant que l'écran est visible.
        if (Prefs.isEnabled(this) && !AssistantService.isRunning()) {
            if (hasPermission(Manifest.permission.RECORD_AUDIO) && isNotificationAccessGranted()) {
                AssistantService.start(this)
            } else {
                Prefs.setEnabled(this, false)
            }
        }
        // Permission retirée dans les réglages : on coupe la fonction proprement.
        if (Prefs.isCallsEnabled(this) && !hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            Prefs.setCallsEnabled(this, false)
            AssistantService.refreshCalls()
        }
        updateUi()
        handler.postDelayed({ updateUi() }, 700)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------ Assistant (notifications)

    private fun tryEnableAssistant() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
            pendingEnable = true
            setSwitch(false)
            permissionLauncher.launch(requiredPermissions())
            return
        }
        if (!isNotificationAccessGranted()) {
            setSwitch(false)
            toast(R.string.toast_need_notif_access)
            openNotificationAccessSettings()
            return
        }
        Prefs.setEnabled(this, true)
        AssistantService.start(this)
        handler.postDelayed({ updateUi() }, 700)
        updateUi()
    }

    private fun disableAssistant() {
        Prefs.setEnabled(this, false)
        AssistantService.stop(this)
        handler.postDelayed({ updateUi() }, 300)
        updateUi()
    }

    private fun sendTestNotification() {
        if (!AssistantService.isRunning()) {
            toast(R.string.toast_start_first)
            return
        }
        val now = System.currentTimeMillis()
        AssistantService.enqueue(
            NotificationInfo(
                key = "test-$now",
                packageName = "com.whatsapp",
                appLabel = "WhatsApp",
                title = "Babacar",
                text = "Bonjour, comment vas-tu ?",
                isMessage = true,
                postTime = now
            )
        )
        toast(R.string.toast_test_sent)
    }

    // ------------------------------------------------------------ Appels entrants (V2)

    private fun enableCalls() {
        if (hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            Prefs.setCallsEnabled(this, true)
            AssistantService.refreshCalls()
            updateUi()
        } else {
            pendingEnableCalls = true
            setCallsSwitch(false)
            callPermissionLauncher.launch(missingCallPermissions())
        }
    }

    private fun disableCalls() {
        Prefs.setCallsEnabled(this, false)
        AssistantService.refreshCalls()
        updateUi()
    }

    private fun requestMissingCallPermissions() {
        val missing = missingCallPermissions()
        if (missing.isEmpty()) return
        val blocked = Prefs.wasCallPermissionAsked(this) &&
            missing.none { shouldShowRequestPermissionRationale(it) }
        if (blocked) {
            // Android n'affiche plus la fenêtre : il faut passer par les réglages de l'application.
            openAppSettings()
        } else {
            callPermissionLauncher.launch(missing)
        }
    }

    private fun onCallPermissionResult() {
        Prefs.setCallPermissionAsked(this, true)
        val phoneOk = hasPermission(Manifest.permission.READ_PHONE_STATE)
        if (pendingEnableCalls) {
            pendingEnableCalls = false
            Prefs.setCallsEnabled(this, phoneOk)
            if (phoneOk) AssistantService.refreshCalls()
        }
        if (!phoneOk) {
            toast(R.string.toast_calls_denied)
            if (!shouldShowRequestPermissionRationale(Manifest.permission.READ_PHONE_STATE)) {
                openAppSettings()
            }
        }
        updateUi()
    }

    private fun callsStatus(callsOn: Boolean, running: Boolean): String {
        if (!callsOn) return getString(R.string.status_calls_off)
        val text = StringBuilder()
        if (!running) text.append(getString(R.string.status_calls_need_assistant)).append("\n\n")
        text.append(statusItem(hasPermission(Manifest.permission.READ_CALL_LOG), R.string.label_call_number))
            .append('\n')
            .append(statusItem(hasPermission(Manifest.permission.READ_CONTACTS), R.string.label_call_name))
            .append('\n')
            .append(statusItem(hasPermission(Manifest.permission.ANSWER_PHONE_CALLS), R.string.label_call_answer))
        return text.toString()
    }

    private fun statusItem(ok: Boolean, labelRes: Int): String =
        getString(R.string.status_item, if (ok) "✔" else "✖", getString(labelRes))

    // ---------------------------------------------------------------- Interface

    private fun updateUi() {
        val running = AssistantService.isRunning()
        setSwitch(running)
        textStatusAssistant.setText(
            if (running) R.string.status_assistant_on else R.string.status_assistant_off
        )
        val notifOk = isNotificationAccessGranted()
        textStatusNotif.setText(if (notifOk) R.string.status_notif_ok else R.string.status_notif_ko)
        textStatusMic.setText(
            if (hasPermission(Manifest.permission.RECORD_AUDIO)) R.string.status_mic_ok
            else R.string.status_mic_ko
        )
        buttonNotifAccess.visibility = if (notifOk) View.GONE else View.VISIBLE

        val callsOn = Prefs.isCallsEnabled(this) && hasPermission(Manifest.permission.READ_PHONE_STATE)
        setCallsSwitch(callsOn)
        textStatusCalls.text = callsStatus(callsOn, running)
        buttonCallPermissions.visibility =
            if (callsOn && missingCallPermissions().isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun setSwitch(checked: Boolean) {
        updatingUi = true
        switchAssistant.isChecked = checked
        updatingUi = false
    }

    private fun setCallsSwitch(checked: Boolean) {
        updatingUi = true
        switchCalls.isChecked = checked
        updatingUi = false
    }

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_LONG).show()

    // --------------------------------------------------------------- Permissions

    private fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun missingCallPermissions(): Array<String> =
        CALL_PERMISSIONS.filter { !hasPermission(it) }.toTypedArray()

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }

    private fun isNotificationAccessGranted() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
