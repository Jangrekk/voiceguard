package com.voiceguard.app

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reçoit toutes les notifications du téléphone (une fois l'accès accordé par l'utilisateur),
 * filtre le bruit, supprime les doublons puis transmet le reste à [AssistantService].
 */
class VoiceGuardListenerService : NotificationListenerService() {

    companion object {
        private val IGNORED_CATEGORIES = setOf(
            Notification.CATEGORY_CALL,
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_STATUS,
            Notification.CATEGORY_NAVIGATION,
            Notification.CATEGORY_ALARM
        )

        private val MESSAGING_PACKAGES = setOf(
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.facebook.orca", "com.google.android.apps.messaging",
            "com.android.mms", "com.samsung.android.messaging", "com.google.android.gm"
        )

        private val KNOWN_APPS = mapOf(
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "org.telegram.messenger" to "Telegram",
            "com.facebook.orca" to "Messenger",
            "com.facebook.katana" to "Facebook",
            "com.instagram.android" to "Instagram",
            "com.google.android.gm" to "Gmail",
            "com.google.android.apps.messaging" to "Messages",
            "com.samsung.android.messaging" to "Messages",
            "com.android.mms" to "Messages"
        )
    }

    override fun onListenerConnected() {
        EventLog.add("SYSTEME", "Accès aux notifications connecté")
    }

    override fun onListenerDisconnected() {
        EventLog.add("SYSTEME", "Accès aux notifications déconnecté")
        runCatching {
            NotificationListenerService.requestRebind(
                ComponentName(this, VoiceGuardListenerService::class.java)
            )
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            process(sbn)
        } catch (e: Exception) {
            EventLog.add("ERREUR", "Traitement d'une notification : ${e.javaClass.simpleName}")
        }
    }

    private fun process(sbn: StatusBarNotification) {
        if (!Prefs.isEnabled(this)) return
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val category = notification.category
        if (category != null && category in IGNORED_CATEGORIES) return

        val extras = notification.extras ?: return
        val title = (extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE))
            ?.toString()?.trim().orEmpty()
        val plain = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val text = if (big.length > plain.length) big else plain

        if (title.isBlank() && text.isBlank()) return

        // L'application est mémorisée même si elle est en sourdine, pour pouvoir la réactiver.
        Prefs.noteSeen(this, sbn.packageName, appLabel(sbn.packageName))
        if (Prefs.isMuted(this, sbn.packageName)) return

        if (NotificationDeduper.isDuplicate(sbn.key, sbn.packageName, title, text)) {
            EventLog.add("DOUBLON", "Notification ignorée (${appLabel(sbn.packageName)})")
            return
        }

        val isMessage = category == Notification.CATEGORY_MESSAGE ||
            category == Notification.CATEGORY_EMAIL ||
            sbn.packageName in MESSAGING_PACKAGES

        val info = NotificationInfo(
            key = sbn.key,
            packageName = sbn.packageName,
            appLabel = appLabel(sbn.packageName),
            title = title,
            text = text,
            isMessage = isMessage,
            postTime = sbn.postTime,
            reply = if (isMessage) findReplyTarget(notification) else null
        )

        if (!AssistantService.enqueue(info)) {
            EventLog.add("ERREUR", "Assistant vocal arrêté : ouvrez VoiceGuard pour le relancer")
        }
    }

    /**
     * Cherche l'action « Répondre » : celle qui accepte une saisie libre (RemoteInput).
     * WhatsApp, Messages, Telegram… la fournissent dans la notification.
     */
    @Suppress("DEPRECATION")
    private fun findReplyTarget(notification: Notification): ReplyTarget? {
        val actions = ArrayList<Notification.Action>()
        notification.actions?.let { actions.addAll(it) }
        try {
            actions.addAll(Notification.WearableExtender(notification).actions)
        } catch (e: Exception) {
            // Pas d'extension « montre » : on ignore.
        }
        for (action in actions) {
            val inputs = action.remoteInputs ?: continue
            if (inputs.none { it.allowFreeFormInput }) continue
            val intent = action.actionIntent ?: continue
            return ReplyTarget(intent, inputs)
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun appLabel(pkg: String): String {
        KNOWN_APPS[pkg]?.let { return it }
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.')
        }
    }
}
