package com.voiceguard.app

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Synthèse vocale (TextToSpeech) et reconnaissance vocale (SpeechRecognizer).
 * Doit être créé et utilisé depuis le thread principal ; tous les rappels
 * (callbacks) reviennent aussi sur le thread principal.
 */
class VoiceEngine(context: Context) {

    sealed class ListenResult {
        data class Heard(val alternatives: List<String>) : ListenResult()
        object NoSpeech : ListenResult()
        data class Failure(val code: Int, val reason: String) : ListenResult()
    }

    companion object {
        private const val LISTEN_TIMEOUT_MS = 12_000L
        private const val SPEAK_WATCHDOG_MS = 90_000L
    }

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val speechAttributes: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANT)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private var tts: TextToSpeech? = null
    private var ready = false
    private val speakCallbacks = HashMap<String, (Boolean) -> Unit>()
    private var focusRequest: AudioFocusRequest? = null

    private var recognizer: SpeechRecognizer? = null
    private var listenToken = 0
    private var watchdog: Runnable? = null

    // ------------------------------------------------------------------ Synthèse vocale

    fun init(onReady: (ok: Boolean, detail: String) -> Unit) {
        tts = TextToSpeech(appContext) { status ->
            main.post {
                val engine = tts
                if (status != TextToSpeech.SUCCESS || engine == null) {
                    ready = false
                    onReady(false, "Moteur de synthèse vocale indisponible")
                    return@post
                }
                val result = engine.setLanguage(Locale.FRENCH)
                val frenchOk = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
                engine.setAudioAttributes(speechAttributes)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) = finishSpeak(utteranceId, true)

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finishSpeak(utteranceId, false)

                    override fun onError(utteranceId: String?, errorCode: Int) =
                        finishSpeak(utteranceId, false)
                })
                ready = true
                onReady(
                    true,
                    if (frenchOk) "Synthèse vocale prête (français)"
                    else "Voix française absente : voix par défaut utilisée"
                )
            }
        }
    }

    fun speak(text: String, onDone: (Boolean) -> Unit) {
        val engine = tts
        if (!ready || engine == null) {
            onDone(false)
            return
        }
        val id = UUID.randomUUID().toString()
        speakCallbacks[id] = onDone
        requestFocus()
        val maxLength = TextToSpeech.getMaxSpeechInputLength() - 1
        val result = engine.speak(text.take(maxLength), TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) {
            speakCallbacks.remove(id)
            abandonFocus()
            onDone(false)
            return
        }
        main.postDelayed({
            if (speakCallbacks.containsKey(id)) {
                tts?.stop()
                finishSpeak(id, false)
            }
        }, SPEAK_WATCHDOG_MS)
    }

    private fun finishSpeak(id: String?, success: Boolean) {
        main.post {
            val callback = id?.let { speakCallbacks.remove(it) } ?: return@post
            abandonFocus()
            callback(success)
        }
    }

    private fun requestFocus() {
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(speechAttributes)
            .build()
        focusRequest = request
        audioManager.requestAudioFocus(request)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    // ------------------------------------------------------------ Reconnaissance vocale

    /**
     * Écoute une phrase. [timeoutMs] borne l'attente ; [silenceMs] (facultatif) allonge le silence
     * toléré avant de considérer la phrase terminée, utile pour dicter un message.
     */
    fun listen(
        timeoutMs: Long = LISTEN_TIMEOUT_MS,
        silenceMs: Long? = null,
        onResult: (ListenResult) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onResult(ListenResult.Failure(-1, "reconnaissance vocale indisponible sur cet appareil"))
            return
        }
        stopListening()
        val token = ++listenToken

        val rec = try {
            SpeechRecognizer.createSpeechRecognizer(appContext)
        } catch (e: Exception) {
            onResult(ListenResult.Failure(-2, "création du module impossible"))
            return
        }
        recognizer = rec

        var finished = false
        val finish: (ListenResult) -> Unit = { result ->
            if (!finished && token == listenToken) {
                finished = true
                clearWatchdog()
                destroy(rec)
                if (recognizer === rec) recognizer = null
                onResult(result)
            }
        }

        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> finish(ListenResult.NoSpeech)
                    else -> finish(ListenResult.Failure(error, describeError(error)))
                }
            }

            override fun onResults(results: Bundle?) {
                val list = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    .orEmpty()
                if (list.isEmpty()) finish(ListenResult.NoSpeech)
                else finish(ListenResult.Heard(list))
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
            if (silenceMs != null) {
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, silenceMs)
                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
                    silenceMs
                )
            }
        }

        val timeout = Runnable { finish(ListenResult.NoSpeech) }
        watchdog = timeout
        main.postDelayed(timeout, timeoutMs)

        try {
            rec.startListening(intent)
        } catch (e: Exception) {
            finish(ListenResult.Failure(-3, "démarrage de l'écoute impossible"))
        }
    }

    fun stopListening() {
        listenToken++
        clearWatchdog()
        recognizer?.let { destroy(it) }
        recognizer = null
    }

    private fun clearWatchdog() {
        watchdog?.let { main.removeCallbacks(it) }
        watchdog = null
    }

    private fun destroy(rec: SpeechRecognizer) {
        main.post {
            runCatching { rec.cancel() }
            runCatching { rec.destroy() }
        }
    }

    private fun describeError(code: Int): String = when (code) {
        1 -> "délai réseau dépassé"
        2 -> "erreur réseau"
        3 -> "erreur audio"
        4 -> "erreur du serveur"
        5 -> "erreur du client"
        8 -> "reconnaissance déjà occupée"
        9 -> "permission du micro manquante"
        10 -> "trop de requêtes"
        11 -> "serveur déconnecté"
        12 -> "langue non prise en charge"
        13 -> "langue indisponible"
        else -> "erreur inconnue"
    }

    /** Coupe immédiatement la parole et l'écoute, sans appeler les rappels en attente. */
    fun stopAll() {
        stopListening()
        speakCallbacks.clear()
        runCatching { tts?.stop() }
        abandonFocus()
    }

    // ---------------------------------------------------------------------- Fin de vie

    fun shutdown() {
        stopListening()
        speakCallbacks.clear()
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        ready = false
        abandonFocus()
    }
}
